3I/ATLAS as a natural laboratory for TCDS — arXiv-ready package
Date: 2025-09-17

Files (root):
- 3I_ATLAS_TCDS_arXiv_bilingual.tex   # main LaTeX (pdfLaTeX)
- refs.bib                            # bibliography
- Q_Ni_CN_vs_r.png                    # Fig. 1
- ICC_sigma_vs_r.png                  # Fig. 2
- anisotropy_3p32au.png               # Fig. 3a
- anisotropy_2p85au.png               # Fig. 3b

Ancillary (optional, for reproducibility):
- anc/3I_ATLAS_TCDS_tests.xlsx

Compile locally (pdfLaTeX route):
1) pdflatex 3I_ATLAS_TCDS_arXiv_bilingual.tex
2) bibtex   3I_ATLAS_TCDS_arXiv_bilingual
3) pdflatex 3I_ATLAS_TCDS_arXiv_bilingual.tex
4) pdflatex 3I_ATLAS_TCDS_arXiv_bilingual.tex

Suggested arXiv metadata:
- Primary category: astro-ph.EP
- Cross-list (optional): astro-ph.GA
- License: CC BY 4.0 (or arXiv non-exclusive license)
- Comments: 8 pages, 3 figures + 1 table; bilingual abstract; ancillary XLSX.

Notes:
- Figures are PNG and paths are flat (root); no EPS required.
- The XLSX is not used by TeX; it is provided in anc/ as supplementary data.
- Ensure ORCID is linked to your arXiv account for author attribution.
